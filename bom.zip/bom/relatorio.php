<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'professor' && $_SESSION['user_role'] !== 'admin')) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'];
$user_avatar = $_SESSION['user_avatar'] ?? "https://ui-avatars.com/api/?name=" . urlencode($user_name) . "&background=111827&color=fff";

$mensagem = '';
$erro = '';

// Processar avaliação
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_id'])) {
    $report_id = $_POST['report_id'];
    $feedback = $_POST['feedback'] ?? '';
    $rating = $_POST['rating'] ?? 5; // Assumindo 5 se não vier

    try {
        $stmt = $pdo->prepare("UPDATE relatorios SET feedback = :feedback, classificacao = :rating, avaliado_em = NOW() WHERE id = :id");
        $stmt->execute(['feedback' => $feedback, 'rating' => $rating, 'id' => $report_id]);
        $mensagem = "Avaliação enviada com sucesso!";
    } catch (PDOException $e) {
        $erro = "Erro ao avaliar: " . $e->getMessage();
    }
}

// Obter lista de relatórios (sidebar)
// Agrupado por aluno ou listado cronologicamente
$sql = "
    SELECT r.id, r.titulo, r.submetido_em, u.nome as nome_aluno, u.avatar_url
    FROM relatorios r
    JOIN estagios e ON r.estagio_id = e.id
    JOIN utilizadores u ON e.aluno_id = u.id
    ORDER BY r.submetido_em DESC
";
$relatorios_lista = $pdo->query($sql)->fetchAll();

// Obter relatório selecionado
$relatorio_atual = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("
        SELECT r.*, u.nome as nome_aluno, u.avatar_url
        FROM relatorios r
        JOIN estagios e ON r.estagio_id = e.id
        JOIN utilizadores u ON e.aluno_id = u.id
        WHERE r.id = :id
    ");
    $stmt->execute(['id' => $id]);
    $relatorio_atual = $stmt->fetch();
} elseif (count($relatorios_lista) > 0) {
    // Seleciona o primeiro por padrão
    $relatorio_atual_id = $relatorios_lista[0]['id'];
    $stmt = $pdo->prepare("
        SELECT r.*, u.nome as nome_aluno, u.avatar_url
        FROM relatorios r
        JOIN estagios e ON r.estagio_id = e.id
        JOIN utilizadores u ON e.aluno_id = u.id
        WHERE r.id = :id
    ");
    $stmt->execute(['id' => $relatorio_atual_id]);
    $relatorio_atual = $stmt->fetch();
}

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - InternFLOW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/relatorio.css">
    <style>
        /* Ajuste para seleção na sidebar */
        .user-item a { text-decoration: none; color: inherit; display: flex; align-items: center; width: 100%; gap: 10px; }
        .user-item.active { background-color: #f3f4f6; border-left: 4px solid #7c3aed; }
        .btn-submit-eval { background-color: #7c3aed; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-brand">
            <a href="dashboard-professor.php" style="text-decoration: none; display: flex; align-items: center; gap: 12px; color: inherit;">
                <div class="logo-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                <span class="logo-text">InternFLOW</span>
            </a>
        </div>
        
        <div class="nav-center-links">
            <a href="dashboard-professor.php">Painel</a>
            <a href="estagios.php">Gerir Estágios</a>
            <a href="relatorio.php" class="active-purple">Relatórios</a>
            <a href="chat.php">Chat</a>
        </div>
        
        <div class="nav-actions">
            <a href="logout.php" class="action-icon" title="Sair"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            <i class="fa-regular fa-bell action-icon"></i>
            <i class="fa-solid fa-gear action-icon"></i>
            <img src="<?php echo htmlspecialchars($user_avatar); ?>" alt="Avatar" class="user-avatar">
        </div>
    </nav>

    <div class="main-content">
        
        <div class="report-layout-container">
            
            <aside class="users-sidebar">
                <?php foreach ($relatorios_lista as $rel): ?>
                <div class="user-item <?php echo ($relatorio_atual && $rel['id'] == $relatorio_atual['id']) ? 'active' : ''; ?>">
                    <a href="relatorio.php?id=<?php echo $rel['id']; ?>">
                        <img src="<?php echo $rel['avatar_url'] ?? "https://ui-avatars.com/api/?name=" . urlencode($rel['nome_aluno']); ?>" alt="Avatar">
                        <div style="display:flex; flex-direction:column; overflow:hidden;">
                            <span style="font-weight:600;"><?php echo htmlspecialchars($rel['nome_aluno']); ?></span>
                            <span style="font-size:12px; color:#6b7280; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;"><?php echo htmlspecialchars($rel['titulo']); ?></span>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
                <?php if (count($relatorios_lista) === 0): ?>
                    <div style="padding: 20px; text-align: center; color: #6b7280;">Nenhum relatório submetido.</div>
                <?php endif; ?>
            </aside>

            <main class="report-view-area">
                
                <?php if ($relatorio_atual): ?>
                    <?php if ($mensagem): ?>
                        <div style="background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                            <?php echo htmlspecialchars($mensagem); ?>
                        </div>
                    <?php endif; ?>

                    <div class="report-header-user">
                        <img src="<?php echo $relatorio_atual['avatar_url'] ?? "https://ui-avatars.com/api/?name=" . urlencode($relatorio_atual['nome_aluno']); ?>" alt="Avatar">
                        <h2><?php echo htmlspecialchars($relatorio_atual['nome_aluno']); ?></h2>
                        <span style="margin-left: auto; color: #6b7280;"><?php echo date('d/m/Y H:i', strtotime($relatorio_atual['submetido_em'])); ?></span>
                    </div>

                    <div class="report-body">
                        <h1 class="report-title"><?php echo htmlspecialchars($relatorio_atual['titulo']); ?></h1>
                        <div style="white-space: pre-wrap; line-height: 1.6; color: #374151;">
                            <?php echo nl2br(htmlspecialchars($relatorio_atual['conteudo'])); ?>
                        </div>
                    </div>

                    <div class="evaluation-section">
                        <h3>Avalie o Relatório</h3>
                        
                        <form method="POST">
                            <input type="hidden" name="report_id" value="<?php echo $relatorio_atual['id']; ?>">
                            
                            <div class="star-rating" style="margin-bottom: 15px;">
                                <!-- Sistema simples de estrelas via select para simplificar o backend/frontend sem JS complexo -->
                                <label>Classificação (1-5): </label>
                                <select name="rating" style="padding: 5px; border-radius: 4px;">
                                    <option value="5" <?php echo ($relatorio_atual['classificacao'] == 5) ? 'selected' : ''; ?>>5 Estrelas</option>
                                    <option value="4" <?php echo ($relatorio_atual['classificacao'] == 4) ? 'selected' : ''; ?>>4 Estrelas</option>
                                    <option value="3" <?php echo ($relatorio_atual['classificacao'] == 3) ? 'selected' : ''; ?>>3 Estrelas</option>
                                    <option value="2" <?php echo ($relatorio_atual['classificacao'] == 2) ? 'selected' : ''; ?>>2 Estrelas</option>
                                    <option value="1" <?php echo ($relatorio_atual['classificacao'] == 1) ? 'selected' : ''; ?>>1 Estrela</option>
                                </select>
                            </div>

                            <textarea name="feedback" class="feedback-input" placeholder="Adicione um feedback detalhado..." style="width: 100%; min-height: 100px; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; margin-bottom: 10px;"><?php echo htmlspecialchars($relatorio_atual['feedback'] ?? ''); ?></textarea>
                            
                            <div class="action-row">
                                <button type="submit" class="btn-submit-eval">Submeter Avaliação</button>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="display: flex; justify-content: center; align-items: center; height: 100%; color: #9ca3af;">
                        <p>Selecione um relatório para visualizar.</p>
                    </div>
                <?php endif; ?>

            </main>
        </div>

    </div>
    <script src="js/script.js"></script>
</body>
</html>
