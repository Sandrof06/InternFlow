<?php
session_start();
require_once 'conexao.php';

// Verificar se é professor
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'professor' && $_SESSION['user_role'] !== 'admin')) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'];
$user_avatar = $_SESSION['user_avatar'] ?? "https://ui-avatars.com/api/?name=" . urlencode($user_name) . "&background=111827&color=fff";

$mensagem = '';
$erro = '';

// Lógica para adicionar aluno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_student') {
    $nome_aluno = $_POST['nome'] ?? '';
    $email_aluno = $_POST['email'] ?? '';
    $curso_aluno = $_POST['curso'] ?? ''; // O curso pode ser guardado noutra tabela ou apenas como info, mas na tabela users não tenho campo curso. 
    // Vou assumir que criamos o utilizador. O curso seria usado ao criar o estágio, mas aqui é só registo de aluno.
    // Para simplificar, vou ignorar o curso no registo do user, ou poderia adicionar campo curso na tabela users. 
    // Vou manter simples e criar o user.

    if ($nome_aluno && $email_aluno) {
        try {
            // Verifica se email já existe
            $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = :email");
            $stmt->execute(['email' => $email_aluno]);
            if ($stmt->fetch()) {
                $erro = "Este email já está registado.";
            } else {
                // Cria aluno com senha padrão '123456'
                $stmt = $pdo->prepare("INSERT INTO utilizadores (nome, email, senha, tipo_utilizador) VALUES (:nome, :email, '123456', 'aluno')");
                $stmt->execute(['nome' => $nome_aluno, 'email' => $email_aluno]);
                $mensagem = "Aluno adicionado com sucesso!";
            }
        } catch (PDOException $e) {
            $erro = "Erro ao adicionar aluno: " . $e->getMessage();
        }
    } else {
        $erro = "Preencha todos os campos.";
    }
}

// Lógica para remover aluno (se implementado)
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    // Validar se é aluno
    $stmt = $pdo->prepare("DELETE FROM utilizadores WHERE id = :id AND tipo_utilizador = 'aluno'");
    $stmt->execute(['id' => $delete_id]);
    header("Location: dashboard-professor.php"); // Limpa a URL
    exit;
}

// Obter contagens de estágios
$stats = [
    'aceite' => 0,
    'pendente' => 0,
    'nao_apto' => 0
];

$stmt = $pdo->query("SELECT estado, COUNT(*) as total FROM estagios GROUP BY estado");
while ($row = $stmt->fetch()) {
    if (isset($stats[$row['estado']])) {
        $stats[$row['estado']] = $row['total'];
    }
}

// Obter lista de alunos
$alunos = $pdo->query("SELECT * FROM utilizadores WHERE tipo_utilizador = 'aluno' ORDER BY id DESC LIMIT 10")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Professor - InternFLOW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/professor.css">
</head>
<body>

    <nav class="navbar">
        <div class="nav-brand">
            <a href="dashboard-professor.php" style="text-decoration: none; display: flex; align-items: center; gap: 12px; color: inherit;">
                <div class="logo-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                <span class="logo-text">InternFLOW</span>
            </a>
        </div>
        
        <div class="nav-center-links">
            <a href="dashboard-professor.php" class="active-purple">Painel</a>
            <a href="estagios.php">Gerir Estágios</a>
            <a href="relatorio.php">Relatórios</a>
            <a href="chat.php">Chat</a>
        </div>
        
        <div class="nav-actions">
            <a href="logout.php" class="action-icon" title="Sair"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            <i class="fa-regular fa-bell action-icon"></i>
            <i class="fa-solid fa-gear action-icon"></i>
            <img src="<?php echo htmlspecialchars($user_avatar); ?>" alt="Avatar" class="user-avatar">
        </div>
    </nav>

    <div class="main-content">
        
        <h1 class="page-title">Painel do Professor</h1>

        <h2 class="section-title">Visão Geral do Estado dos Estágios</h2>
        <div class="cards-container">
            <div class="card stat-card">
                <div class="card-content">
                    <div class="card-header">
                        <span class="card-label">Estágios Aceites</span>
                        <div class="icon-wrapper"><i class="fa-regular fa-circle-check"></i></div>
                    </div>
                    <strong class="card-value"><?php echo $stats['aceite']; ?></strong>
                    <span class="card-sub">Confirmados e em andamento</span>
                </div>
            </div>
            
            <div class="card stat-card">
                <div class="card-content">
                    <div class="card-header">
                        <span class="card-label">Estágios Pendentes</span>
                        <div class="icon-wrapper"><i class="fa-solid fa-hourglass-half"></i></div>
                    </div>
                    <strong class="card-value"><?php echo $stats['pendente']; ?></strong>
                    <span class="card-sub">Aguardando aprovação ou feedback</span>
                </div>
            </div>

            <div class="card stat-card">
                <div class="card-content">
                    <div class="card-header">
                        <span class="card-label">Estágios Não Aptos</span>
                        <div class="icon-wrapper"><i class="fa-regular fa-circle-xmark"></i></div>
                    </div>
                    <strong class="card-value"><?php echo $stats['nao_apto']; ?></strong>
                    <span class="card-sub">Rejeitados ou cancelados</span>
                </div>
            </div>
        </div>

        <div class="management-section">
            <h2 class="section-title">Gestão de Alunos</h2>
            
            <div class="tab-group">
                <button class="tab-btn active">Adicionar Aluno</button>
                <!-- Botão remover apenas visual por enquanto, ou poderia alternar visibilidade -->
            </div>

            <?php if ($mensagem): ?>
                <div style="background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                    <?php echo htmlspecialchars($mensagem); ?>
                </div>
            <?php endif; ?>
            <?php if ($erro): ?>
                <div style="background-color: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <div class="form-area">
                <h3>Adicionar Novo Aluno</h3>
                <form class="add-student-form" method="POST" action="dashboard-professor.php">
                    <input type="hidden" name="action" value="add_student">
                    
                    <div class="form-col flex-grow">
                        <label>Nome do Aluno</label>
                        <div class="input-with-icon">
                            <i class="fa-regular fa-user"></i>
                            <input type="text" name="nome" placeholder="Nome Completo" required>
                        </div>
                    </div>

                    <div class="form-col flex-grow">
                        <label>Email Institucional</label>
                        <div class="input-with-icon">
                            <i class="fa-regular fa-envelope"></i>
                            <input type="email" name="email" placeholder="email.aluno@instituicao.edu.br" required>
                        </div>
                    </div>
                    
                    <!-- Curso removido pois não está na tabela users, mas poderia ser adicionado -->
                    
                    <div class="form-col btn-col">
                        <button type="submit" class="btn-primary">Adicionar</button>
                    </div>
                </form>
            </div>

            <div class="student-list-section">
                <p class="list-title">Alunos Recentemente Adicionados:</p>
                
                <div class="student-list">
                    <?php foreach ($alunos as $aluno): ?>
                    <div class="student-row">
                        <span class="student-email" style="font-weight: 500;"><?php echo htmlspecialchars($aluno['nome']); ?></span>
                        <span class="student-email"><?php echo htmlspecialchars($aluno['email']); ?></span>
                        <a href="dashboard-professor.php?delete_id=<?php echo $aluno['id']; ?>" class="course-badge badge-danger" style="text-decoration:none; cursor:pointer;" onclick="return confirm('Tem a certeza que deseja remover este aluno?');">Remover</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

    </div>
    <script src="js/script.js"></script>
</body>
</html>
