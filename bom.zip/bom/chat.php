<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$meu_id = $_SESSION['user_id'];
$meu_tipo = $_SESSION['user_role'];
$user_name = $_SESSION['user_name'];
$user_avatar = $_SESSION['user_avatar'] ?? "https://ui-avatars.com/api/?name=" . urlencode($user_name) . "&background=111827&color=fff";

// Enviar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['destinatario_id']) && isset($_POST['conteudo'])) {
    $destinatario_id = $_POST['destinatario_id'];
    $conteudo = trim($_POST['conteudo']);

    if ($conteudo) {
        $stmt = $pdo->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, conteudo) VALUES (:remetente, :destinatario, :conteudo)");
        $stmt->execute(['remetente' => $meu_id, 'destinatario' => $destinatario_id, 'conteudo' => $conteudo]);
    }
    // Redireciona para evitar reenvio
    header("Location: chat.php?user_id=" . $destinatario_id);
    exit;
}

// Obter lista de contatos (conversas)
// Se for professor, lista alunos. Se for aluno, lista professores.
// Ou melhor: Lista qualquer um com quem já trocou mensagens, ou todos os usuários do tipo oposto.
// Para simplificar: Se sou professor, listo todos os alunos. Se sou aluno, listo professores.

$contatos = [];
if ($meu_tipo === 'professor' || $meu_tipo === 'admin') {
    // Buscar todos os alunos
    $contatos = $pdo->query("SELECT id, nome, avatar_url FROM utilizadores WHERE tipo_utilizador = 'aluno'")->fetchAll();
} else {
    // Buscar todos os professores
    $contatos = $pdo->query("SELECT id, nome, avatar_url FROM utilizadores WHERE tipo_utilizador = 'professor' OR tipo_utilizador = 'admin'")->fetchAll();
}

// Selecionar conversa atual
$conversa_atual_id = $_GET['user_id'] ?? null;
$conversa_atual_user = null;
$mensagens = [];

if ($conversa_atual_id) {
    // Buscar dados do usuário selecionado
    $stmt = $pdo->prepare("SELECT id, nome, avatar_url FROM utilizadores WHERE id = :id");
    $stmt->execute(['id' => $conversa_atual_id]);
    $conversa_atual_user = $stmt->fetch();

    if ($conversa_atual_user) {
        // Buscar mensagens
        $stmt = $pdo->prepare("
            SELECT * FROM mensagens 
            WHERE (remetente_id = :eu AND destinatario_id = :ele) 
               OR (remetente_id = :ele AND destinatario_id = :eu)
            ORDER BY enviada_em ASC
        ");
        $stmt->execute(['eu' => $meu_id, 'ele' => $conversa_atual_id]);
        $mensagens = $stmt->fetchAll();
        
        // Marcar como lidas (as que recebi)
        $stmt = $pdo->prepare("UPDATE mensagens SET lida = 1 WHERE destinatario_id = :eu AND remetente_id = :ele AND lida = 0");
        $stmt->execute(['eu' => $meu_id, 'ele' => $conversa_atual_id]);
    }
} elseif (count($contatos) > 0) {
    // Seleciona o primeiro contato se nenhum selecionado
    // Opcional: Redirecionar? Não, só deixar null e mostrar mensagem de boas-vindas
}

// Determinar link do dashboard baseado no tipo
$dashboard_link = ($meu_tipo === 'aluno') ? 'dashboard-aluno.php' : 'dashboard-professor.php';

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - InternFLOW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/chat.css">
    <style>
        .conv-item a { text-decoration: none; color: inherit; display: flex; align-items: center; width: 100%; gap: 10px; }
        .conv-item.active { background-color: #f3f4f6; border-left: 4px solid #7c3aed; }
        .chat-messages { display: flex; flex-direction: column; gap: 15px; padding: 20px; overflow-y: auto; height: calc(100vh - 250px); }
        .message { max-width: 70%; padding: 12px 16px; border-radius: 12px; position: relative; }
        .message.sent { align-self: flex-end; background-color: #7c3aed; color: white; border-bottom-right-radius: 2px; }
        .message.received { align-self: flex-start; background-color: #f3f4f6; color: #1f2937; border-bottom-left-radius: 2px; }
        .message .time { font-size: 10px; opacity: 0.7; margin-top: 5px; display: block; text-align: right; }
        .chat-input-area form { display: flex; width: 100%; gap: 10px; }
        .chat-input-area input { flex: 1; padding: 12px; border: 1px solid #e5e7eb; border-radius: 8px; outline: none; }
        .chat-input-area button { padding: 0 20px; background-color: #7c3aed; color: white; border: none; border-radius: 8px; cursor: pointer; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-brand">
            <a href="<?php echo $dashboard_link; ?>" style="text-decoration: none; display: flex; align-items: center; gap: 12px; color: inherit;">
                <div class="logo-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                <span class="logo-text">InternFLOW</span>
            </a>
        </div>
        
        <div class="nav-center-links">
            <?php if ($meu_tipo === 'aluno'): ?>
                <a href="dashboard-aluno.php">Painel</a>
                <a href="chat.php" class="active-purple">Chat</a>
            <?php else: ?>
                <a href="dashboard-professor.php">Painel</a>
                <a href="estagios.php">Gerir Estágios</a>
                <a href="relatorio.php">Relatórios</a>
                <a href="chat.php" class="active-purple">Chat</a>
            <?php endif; ?>
        </div>
        
        <div class="nav-actions">
            <a href="logout.php" class="action-icon" title="Sair"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            <i class="fa-regular fa-bell action-icon"></i>
            <i class="fa-solid fa-gear action-icon"></i>
            <img src="<?php echo htmlspecialchars($user_avatar); ?>" alt="Avatar" class="user-avatar">
        </div>
    </nav>

    <div class="main-content">
        
        <div class="chat-layout-container">
            
            <aside class="chat-sidebar">
                <h2 class="sidebar-title">Contatos</h2>
                
                <div class="conversation-list">
                    <?php foreach ($contatos as $contato): ?>
                    <div class="conv-item <?php echo ($conversa_atual_id == $contato['id']) ? 'active' : ''; ?>">
                        <a href="chat.php?user_id=<?php echo $contato['id']; ?>">
                            <img src="<?php echo $contato['avatar_url'] ?? "https://ui-avatars.com/api/?name=" . urlencode($contato['nome']); ?>" alt="Avatar">
                            <span class="conv-name"><?php echo htmlspecialchars($contato['nome']); ?></span>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </aside>

            <main class="chat-window-area">
                
                <?php if ($conversa_atual_user): ?>
                    <div class="chat-header">
                        <img src="<?php echo $conversa_atual_user['avatar_url'] ?? "https://ui-avatars.com/api/?name=" . urlencode($conversa_atual_user['nome']); ?>" alt="Avatar">
                        <h3><?php echo htmlspecialchars($conversa_atual_user['nome']); ?></h3>
                    </div>

                    <div class="chat-messages" id="message-container">
                        <?php foreach ($mensagens as $msg): ?>
                            <div class="message <?php echo ($msg['remetente_id'] == $meu_id) ? 'sent' : 'received'; ?>">
                                <p><?php echo htmlspecialchars($msg['conteudo']); ?></p>
                                <span class="time"><?php echo date('H:i', strtotime($msg['enviada_em'])); ?></span>
                            </div>
                        <?php endforeach; ?>
                        <?php if (count($mensagens) == 0): ?>
                            <p style="text-align: center; color: #9ca3af; margin-top: 20px;">Nenhuma mensagem. Comece a conversa!</p>
                        <?php endif; ?>
                    </div>

                    <div class="chat-input-area">
                        <form method="POST">
                            <input type="hidden" name="destinatario_id" value="<?php echo $conversa_atual_id; ?>">
                            <input type="text" name="conteudo" placeholder="Digite a sua mensagem..." required autocomplete="off">
                            <button type="submit" class="btn-send"><i class="fa-regular fa-paper-plane"></i></button>
                        </form>
                    </div>
                    
                    <script>
                        // Rolar para o fim automaticamente
                        var msgContainer = document.getElementById("message-container");
                        msgContainer.scrollTop = msgContainer.scrollHeight;
                    </script>

                <?php else: ?>
                    <div style="display: flex; justify-content: center; align-items: center; height: 100%; color: #9ca3af;">
                        <p>Selecione um contato para conversar.</p>
                    </div>
                <?php endif; ?>

            </main>
        </div>

    </div>
    <script src="js/script.js"></script>
</body>
</html>
