<?php
session_start();
require_once 'conexao.php';

// Verificar permissão (apenas admin)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'];
$user_avatar = $_SESSION['user_avatar'] ?? "https://ui-avatars.com/api/?name=" . urlencode($user_name) . "&background=random";

$mensagem = '';
$erro = '';

// Adicionar Professor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_professor') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    
    if ($nome && $email) {
        try {
            $stmt = $pdo->prepare("INSERT INTO utilizadores (nome, email, senha, tipo_utilizador) VALUES (:nome, :email, '123456', 'professor')");
            $stmt->execute(['nome' => $nome, 'email' => $email]);
            $mensagem = "Professor adicionado com sucesso!";
        } catch (PDOException $e) {
            $erro = "Erro ao adicionar: " . $e->getMessage();
        }
    } else {
        $erro = "Preencha todos os campos.";
    }
}

// Remover Professor
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM utilizadores WHERE id = :id AND tipo_utilizador = 'professor'");
    $stmt->execute(['id' => $id]);
    header("Location: dashboard-admin.php");
    exit;
}

// Estatísticas
$total_professores = $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE tipo_utilizador = 'professor'")->fetchColumn();
$total_alunos = $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE tipo_utilizador = 'aluno'")->fetchColumn();
$total_estagios = $pdo->query("SELECT COUNT(*) FROM estagios WHERE estado = 'aceite'")->fetchColumn();

// Lista de Professores
$professores = $pdo->query("SELECT * FROM utilizadores WHERE tipo_utilizador = 'professor' ORDER BY id DESC")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - InternFLOW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

    <nav class="navbar">
        <div class="nav-brand">
            <a href="dashboard-admin.php" style="text-decoration: none; display: flex; align-items: center; gap: 12px; color: inherit;">
                <div class="logo-icon">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <span class="logo-text">InternFLOW</span>
            </a>
        </div>
        
        <div class="nav-actions">
            <a href="logout.php" class="action-icon" title="Sair">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <i class="fa-regular fa-bell action-icon"></i>
            <i class="fa-solid fa-gear action-icon"></i>
            <img src="<?php echo htmlspecialchars($user_avatar); ?>" alt="Avatar" class="user-avatar">
        </div>
    </nav>

    <div class="main-content">
        
        <h1 class="page-title">Dashboard do Administrador</h1>

        <?php if ($mensagem): ?>
            <div style="background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($mensagem); ?>
            </div>
        <?php endif; ?>
        <?php if ($erro): ?>
            <div style="background-color: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($erro); ?>
            </div>
        <?php endif; ?>

        <h2 class="section-title">Visão Geral</h2>
        <div class="cards-container">
            <div class="card">
                <div class="card-info">
                    <span class="card-label">Total de Professores</span>
                    <strong class="card-value"><?php echo $total_professores; ?></strong>
                    <span class="card-sub">Professores registados</span>
                </div>
                <div class="card-icon-box">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="card">
                <div class="card-info">
                    <span class="card-label">Total de Alunos</span>
                    <strong class="card-value"><?php echo $total_alunos; ?></strong>
                    <span class="card-sub">Alunos ativos</span>
                </div>
                <div class="card-icon-box">
                    <i class="fa-solid fa-book"></i>
                </div>
            </div>
            <div class="card">
                <div class="card-info">
                    <span class="card-label">Estágios Ativos</span>
                    <strong class="card-value"><?php echo $total_estagios; ?></strong>
                    <span class="card-sub">Estágios em andamento</span>
                </div>
                <div class="card-icon-box">
                    <i class="fa-solid fa-briefcase"></i>
                </div>
            </div>
        </div>

        <div class="table-header-group">
            <h2 class="section-title">Gerenciamento de Professores</h2>
            <!-- Form simples para adicionar -->
            <form method="POST" class="form-inline">
                <input type="hidden" name="action" value="add_professor">
                <input type="text" name="nome" placeholder="Nome" required class="form-input">
                <input type="email" name="email" placeholder="Email" required class="form-input">
                <button type="submit" class="btn-primary">Adicionar</button>
            </form>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th class="text-right" style="text-align: right;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($professores as $prof): ?>
                    <tr>
                        <td>#<?php echo $prof['id']; ?></td>
                        <td><?php echo htmlspecialchars($prof['nome']); ?></td>
                        <td><?php echo htmlspecialchars($prof['email']); ?></td>
                        <td class="actions-cell">
                            <a href="dashboard-admin.php?delete_id=<?php echo $prof['id']; ?>" class="icon-action text-danger" onclick="return confirm('Tem a certeza?');">
                                <i class="fa-regular fa-trash-can"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>
    <script src="js/script.js"></script>
</body>
</html>
