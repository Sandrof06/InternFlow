<?php
session_start();
require_once 'conexao.php';

// Verificar se é aluno
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'aluno') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_avatar = $_SESSION['user_avatar'] ?? "https://ui-avatars.com/api/?name=" . urlencode($user_name) . "&background=random";

$mensagem = '';
$erro = '';

// Obter estágio do aluno
$stmt = $pdo->prepare("
    SELECT e.*, u.nome as nome_orientador 
    FROM estagios e 
    LEFT JOIN utilizadores u ON e.orientador_id = u.id 
    WHERE e.aluno_id = :aluno_id 
    ORDER BY e.criado_em DESC 
    LIMIT 1
");
$stmt->execute(['aluno_id' => $user_id]);
$estagio = $stmt->fetch();

// Lógica de submissão de relatório
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_report') {
    $titulo = $_POST['titulo'] ?? '';
    $conteudo = $_POST['conteudo'] ?? '';
    
    if (!$estagio) {
        $erro = "Você não tem um estágio ativo para enviar relatórios.";
    } elseif ($titulo && $conteudo) {
        try {
            $stmt = $pdo->prepare("INSERT INTO relatorios (estagio_id, titulo, conteudo) VALUES (:estagio_id, :titulo, :conteudo)");
            $stmt->execute([
                'estagio_id' => $estagio['id'],
                'titulo' => $titulo,
                'conteudo' => $conteudo
            ]);
            $mensagem = "Relatório enviado com sucesso!";
        } catch (PDOException $e) {
            $erro = "Erro ao enviar relatório: " . $e->getMessage();
        }
    } else {
        $erro = "Preencha todos os campos do relatório.";
    }
}

// Obter feedbacks (relatórios com feedback)
$feedbacks = [];
if ($estagio) {
    $stmt = $pdo->prepare("
        SELECT r.*, u.nome as nome_professor 
        FROM relatorios r
        JOIN estagios e ON r.estagio_id = e.id
        LEFT JOIN utilizadores u ON e.orientador_id = u.id
        WHERE r.estagio_id = :estagio_id AND r.feedback IS NOT NULL
        ORDER BY r.avaliado_em DESC
    ");
    $stmt->execute(['estagio_id' => $estagio['id']]);
    $feedbacks = $stmt->fetchAll();
}

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Aluno - InternFLOW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/aluno.css">
</head>
<body>

    <nav class="navbar">
        <div class="nav-brand">
            <a href="dashboard-aluno.php" style="text-decoration: none; display: flex; align-items: center; gap: 12px; color: inherit;">
                <div class="logo-icon">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <span class="logo-text">InternFLOW</span>
            </a>
        </div>
        
        <div class="nav-center-links">
            <a href="dashboard-aluno.php" class="active-purple">Painel</a>
            <a href="chat.php">Chat</a>
        </div>

        <div class="nav-actions">
            <a href="logout.php" class="action-icon" title="Sair">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <i class="fa-regular fa-bell action-icon"></i>
            <i class="fa-solid fa-gear action-icon"></i>
            <img src="<?php echo htmlspecialchars($user_avatar); ?>" alt="Avatar" class="user-avatar">
        </div>
    </nav>

    <div class="main-content">
        
        <h1 class="page-title">Painel do Aluno</h1>

        <?php if ($mensagem): ?>
            <div style="background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($mensagem); ?>
            </div>
        <?php endif; ?>
        <?php if ($erro): ?>
            <div style="background-color: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($erro); ?>
            </div>
        <?php endif; ?>

        <div class="grid-top">
            
            <div class="card stage-card">
                <div class="card-header-icon">
                    <i class="fa-solid fa-briefcase"></i>
                    <h3><?php echo $estagio ? htmlspecialchars($estagio['titulo']) : 'Nenhum Estágio Ativo'; ?></h3>
                </div>
                <p class="card-subtitle">Detalhes do seu estágio atual</p>

                <?php if ($estagio): ?>
                <div class="stage-info-list">
                    <div class="info-item">
                        <i class="fa-solid fa-graduation-cap"></i>
                        <span><strong>Curso:</strong> <?php echo htmlspecialchars($estagio['curso']); ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fa-solid fa-book-open"></i>
                        <span><strong>Área:</strong> <?php echo htmlspecialchars($estagio['area']); ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fa-regular fa-user"></i>
                        <span><strong>Professor Responsável:</strong> <?php echo htmlspecialchars($estagio['nome_orientador'] ?? 'Não atribuído'); ?></span>
                    </div>
                </div>

                <div class="status-area">
                    <span>Estado:</span>
                    <?php
                        $badgeClass = 'badge-gray';
                        $icon = 'fa-circle-question';
                        if ($estagio['estado'] === 'aceite') { $badgeClass = 'badge-success'; $icon = 'fa-circle-check'; }
                        elseif ($estagio['estado'] === 'pendente') { $badgeClass = 'badge-warning'; $icon = 'fa-hourglass-half'; } // badge-warning se existir css, senão badge-yellow
                        elseif ($estagio['estado'] === 'nao_apto') { $badgeClass = 'badge-danger'; $icon = 'fa-circle-xmark'; }
                    ?>
                    <span class="<?php echo $badgeClass; ?>"><i class="fa-regular <?php echo $icon; ?>"></i> <?php echo ucfirst($estagio['estado']); ?></span>
                </div>
                <?php else: ?>
                    <p>Você ainda não está associado a um estágio. Fale com seu professor.</p>
                <?php endif; ?>
            </div>

            <div class="card report-card">
                <div class="card-header-icon">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                    <h3>Submeter Relatório</h3>
                </div>
                <p class="card-subtitle">Envie o seu relatório de estágio</p>

                <form class="report-form" method="POST" action="dashboard-aluno.php">
                    <input type="hidden" name="action" value="submit_report">
                    <label>Título do Relatório</label>
                    <input type="text" name="titulo" placeholder="Relatório Mensal de Progresso" required>
                    
                    <label>Descrição do Relatório</label>
                    <textarea name="conteudo" placeholder="Descreva as suas atividades, aprendizagens, desafios e conquistas..." required></textarea>

                    <button type="submit" class="btn-primary full-width">Enviar Relatório</button>
                </form>
            </div>
        </div>

        <div class="grid-bottom">
            
            <div class="card">
                <div class="card-header-icon">
                    <i class="fa-regular fa-envelope"></i>
                    <h3>Feedback do Professor</h3>
                </div>
                <p class="card-subtitle">Revisões e comentários sobre os seus relatórios</p>

                <div class="feedback-list">
                    <?php if (count($feedbacks) > 0): ?>
                        <?php foreach ($feedbacks as $fb): ?>
                        <div class="feedback-item">
                            <div class="feedback-meta">
                                <span>De: <?php echo htmlspecialchars($fb['nome_professor']); ?></span>
                                <span class="date"><?php echo date('d/m/Y', strtotime($fb['avaliado_em'])); ?></span>
                            </div>
                            <p><strong>Ref: <?php echo htmlspecialchars($fb['titulo']); ?></strong><br><?php echo htmlspecialchars($fb['feedback']); ?></p>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Ainda não tem feedback disponível.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header-icon">
                    <i class="fa-solid fa-circle-info"></i>
                    <h3>Recursos Úteis</h3>
                </div>
                <p class="card-subtitle">Links e guias para auxiliar o seu estágio</p>

                <div class="resources-list">
                    <a href="#" class="resource-link"><i class="fa-solid fa-link"></i> Guia de Boas Práticas para Estágios</a>
                    <a href="#" class="resource-link"><i class="fa-solid fa-link"></i> Modelo de Relatório de Estágio</a>
                    <a href="#" class="resource-link"><i class="fa-solid fa-link"></i> Dicas para Desenvolvimento Profissional</a>
                </div>
            </div>
        </div>

    </div>
    <script src="js/script.js"></script>
</body>
</html>
